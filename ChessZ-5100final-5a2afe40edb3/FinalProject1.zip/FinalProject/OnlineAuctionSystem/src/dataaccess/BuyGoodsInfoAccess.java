package dataaccess;

import java.sql.ResultSet;

public interface BuyGoodsInfoAccess {
	public ResultSet getBuyGoodsInfo(String sql);

}
