package dataaccess;

public interface LeaveWordAccess {

	public boolean addLeaveWord(String sql);
}
