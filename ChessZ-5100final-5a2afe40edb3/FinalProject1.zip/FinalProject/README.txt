The folder “Project” is a simple prototype of java application version.

And our final project is implemented using web front end and database environment system, which is in the folder “OnlineAuctionSystem”, to run this project, please read the README.txt under that project folder and follow the instructions.